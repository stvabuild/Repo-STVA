# -*- coding: utf-8 -*-

import re, base64

from platformcode import logger
from core import scrapertools


FER_DEBUG = False # True per analitzar, False per publicar

def debuga(tit, txt=None):
    logger.info(tit)
    if txt: logger.debug(txt)


def resoldre_x92 (valor1, valor2):
    reto = ''
    lista = range(256)
    j = 0
    for i in range(256):
        j = (j + lista[i] + ord(valor1[i % len(valor1)])) % 256
        k = lista[i]
        lista[i] = lista[j]
        lista[j] = k
    
    m = 0; j = 0;
    for i in range(len(valor2)):
        m = (m + 1) % 256
        j = (j + lista[m]) % 256
        k = lista[m]
        lista[m] = lista[j]
        lista[j] = k
        reto += chr(ord(valor2[i]) ^ lista[(lista[m] + lista[j]) % 256])

    return reto


def resoldre_function(data):
    # function yNSickVMuR(){ return 11; }
    matches = scrapertools.find_multiple_matches(data, 'function (\w+)\(\)\{ return (\d+); \}')
    for nom, val in matches:
        data = data.replace('function %s(){ return %s; }' % (nom, val), '')
        data = data.replace(nom+'()', val)

    # function yNSickVMuR(){ return "z5bY6LhjgUeuybR"; }
    matches = scrapertools.find_multiple_matches(data, 'function (\w+)\(\)\{ return "([^"]*)"; \}')
    for nom, val in matches:
        data = data.replace('function %s(){ return "%s"; }' % (nom, val), '')
        data = data.replace(nom+'()', '"%s"' % val)

    # function yNSickVMuR(){ return 'z5bY6LhjgUeuybR'; }
    matches = scrapertools.find_multiple_matches(data, "function (\w+)\(\)\{ return '([^']*)'; \}")
    for nom, val in matches:
        data = data.replace("function %s(){ return '%s'; }" % (nom, val), '')
        data = data.replace(nom+'()', '"%s"' % val)

    # function qZicJftTzM(umcE){ return umcE.concat(''); } i qZicJftTzM(xxx)
    matches = scrapertools.find_multiple_matches(data, '(function (\w+)\(([^\)]+)\)\{ return ([^;]+); \})')
    for tot, nom, parm, val in matches:
        data = data.replace(tot, '')
        data = re.sub('%s\(([^\)]+)\)' % nom, lambda m: val.replace(parm, m.group(1)), data)

    return data

def resoldre_mates(data):
    # (8*2)+1
    matches = scrapertools.find_multiple_matches(data, '\((\d+)\*(\d+)\)\+(\d+)')
    for num1, num2, num3 in matches:
        data = data.replace('(%s*%s)+%s' % (num1, num2, num3), str((int(num1)*int(num2))+int(num3)))

    return data

def resoldre_charat(data):
    # "6guHxeGXF9BbnhcStf90nTY27it0W6aodi1Kc1e5zguOPl3%4RmJ2dv$IVL3".charAt(44)
    matches = scrapertools.find_multiple_matches(data, '"([^"]+)"\.charAt\((\d+)\)')
    for val, pos in matches:
        data = data.replace('"%s".charAt(%s)' % (val, pos), '"%s"' % val[int(pos)])

    return data

def resoldre_substring(data):
    # "6guHxeGXF9BbnhcStf90nTY27it0W6aodi1Kc1e5zguOPl3%4RmJ2dv$IVL3".substring(36, 41)
    matches = scrapertools.find_multiple_matches(data, '"([^"]+)"\.substring\((\d+), (\d+)\)')
    for val, pos1, pos2 in matches:
        data = data.replace('"%s".substring(%s, %s)' % (val, pos1, pos2), '"%s"' % val[int(pos1):int(pos2)])

    return data

def resoldre_atob(data):
    # atob("amlYMzhaSA==")
    matches = scrapertools.find_multiple_matches(data, 'atob\("([^"]*)"\)')
    for val in matches:
        data = data.replace('atob("%s")' % val, '"%s"' % base64.b64decode(val))
    return data

def resoldre_var(data):
    # var _0xxfATo = 51;
    matches = scrapertools.find_multiple_matches(data, '(var (\w+)\s*=\s*(\d+);)')
    for tot, nom, val in matches:
        data = data.replace(tot, '')
        data = data.replace(nom, val)

    # var RNHSf = "z5bY6LhjgUeuybR";
    matches = scrapertools.find_multiple_matches(data, '(var (\w+)\s*=\s*"([^"]*)";)')
    for tot, nom, val in matches:
        if nom not in ['x92a', 'x92b']:
            data = data.replace(tot, '')
            data = data.replace(nom, '"%s"' % val)

    # var RNHSf = 'z5bY6LhjgUeuybR';
    matches = scrapertools.find_multiple_matches(data, "(var (\w+)\s*=\s*'([^']*)';)")
    for tot, nom, val in matches:
        if nom not in ['x92a', 'x92b']:
            data = data.replace(tot, '')
            data = data.replace(nom, '"%s"' % val)

    return data

def resoldre_concat(data):
    # "GjJMboLnOv92bnuN6T935aRshdI6mc".concat("iffj80uhAPHFBgsXek2w0WVozSxdYg");
    matches = scrapertools.find_multiple_matches(data, '"([^"]*)"\.concat\("([^"]*)"\)')
    for val1, val2 in matches:
        data = data.replace('"%s".concat("%s")' % (val1, val2), '"%s%s"' % (val1, val2))

    # 'GjJMboLnOv92bnuN6T935aRshdI6mc'.concat('iffj80uhAPHFBgsXek2w0WVozSxdYg');
    matches = scrapertools.find_multiple_matches(data, "'([^']*)'\.concat\('([^']*)'\)")
    for val1, val2 in matches:
        data = data.replace("'%s'.concat('%s')" % (val1, val2), '"%s%s"' % (val1, val2))

    # "GjJMboLnOv92bnuN6T935aRshdI6mc".concat('iffj80uhAPHFBgsXek2w0WVozSxdYg');
    matches = scrapertools.find_multiple_matches(data, '"([^"]*)"\.concat\(\'([^\']*)\'\)')
    for val1, val2 in matches:
        data = data.replace('"%s".concat(\'%s\')' % (val1, val2), '"%s%s"' % (val1, val2))

    # 'GjJMboLnOv92bnuN6T935aRshdI6mc'.concat("iffj80uhAPHFBgsXek2w0WVozSxdYg");
    matches = scrapertools.find_multiple_matches(data, '\'([^\']*)\'\.concat\("([^"]*)"\)')
    for val1, val2 in matches:
        data = data.replace('\'%s\'.concat("%s")' % (val1, val2), '"%s%s"' % (val1, val2))

    # "GjJMboLnOv92bnuN6T935aRshdI6mc"+"iffj80uhAPHFBgsXek2w0WVozSxdYg"
    # [^.]+ per evitar "aa"+"bb".concat("cc")
    matches = scrapertools.find_multiple_matches(data, '("([^"]*)"\+"([^"]*)")[^.]+')
    for tot, val1, val2 in matches:
        data = data.replace(tot, '"%s%s"' % (val1, val2))

    return data


def cicle_resoldre(data_js):
    data_js = resoldre_function(data_js)
    if FER_DEBUG: debuga('resoldre_function', data_js)

    data_js = resoldre_atob(data_js)
    if FER_DEBUG: debuga('resoldre_atob', data_js)

    data_js = resoldre_var(data_js)
    if FER_DEBUG: debuga('resoldre_var', data_js)
    
    data_js = resoldre_concat(data_js)
    if FER_DEBUG: debuga('resoldre_concat', data_js)

    data_js = resoldre_charat(data_js)
    if FER_DEBUG: debuga('resoldre_charat', data_js)

    data_js = resoldre_substring(data_js)
    if FER_DEBUG: debuga('resoldre_substring', data_js)

    data_js = resoldre_mates(data_js)
    if FER_DEBUG: debuga('resoldre_mates', data_js)

    return data_js



def decode_url(data):
    logger.info()

    js = scrapertools.find_multiple_matches(data, '<script type="application/javascript">(.*?)</script>')
    if len(js) == 1:
        data_js = js[0]
    else:
        data_js = js[0] + js[1]
    if FER_DEBUG: debuga('js inicial', data_js)
    
    # netejar dades no necessàries
    data_js = re.sub('var _0x739c=\[.*?\];', '', data_js)
    data_js = re.sub('var _0xbec2=\[.*?\];', '', data_js)
    data_js = re.sub('function x92\(.*?return _0xba03x7};', '', data_js)
    if FER_DEBUG: debuga('js netejat', data_js)

    # corregir getElementById, getAttribute
    matches = scrapertools.find_multiple_matches(data, '" id="([^"]+)" val="([^"]*)"')
    for v_id, v_val in matches:
        data_js = data_js.replace('var %s = document.getElementById("%s");' % (v_id, v_id), '')
        data_js = data_js.replace('%s.getAttribute("val")' % v_id, '"%s"' % v_val)
    if FER_DEBUG: debuga('js sense getElementById, getAttribute', data_js)
    
    # extreure crida x92 i convertir en dues variables
    crida_x92 = scrapertools.find_single_match(data_js, 'x92\((.*?),atob\(([^\)]+)\)\)\+ _0x')
    if crida_x92:
        data_js = re.sub('document\[.*?;', '', data_js)
        # ~ logger.debug(crida_x92)
        data_js += ' var x92a = ' + crida_x92[0] + '; '
        data_js += ' var x92b = ' + crida_x92[1] + '; '
        if FER_DEBUG: debuga('js amb variables per crida x92', data_js)
    else:
        crida_x92 = scrapertools.find_single_match(data_js, 'x92\((.*?),\s*atob\(([^\)]+)\)\)')
        if not crida_x92: return ''
        data_js = re.sub('x92\(.*?,\s*atob\([^\)]+\)\)', '""', data_js)
        # ~ logger.debug(crida_x92)
        data_js += ' var x92a = ' + crida_x92[0] + '; '
        data_js += ' var x92b = ' + crida_x92[1] + '; '
        if FER_DEBUG: debuga('js amb variables per crida x92 (alt)', data_js)

    # Interpretar JS (repetir cicle per resoldre vàries vegades)
    for i in range(20):
        if FER_DEBUG: debuga('Cicle %d' % i)
        data_js = cicle_resoldre(data_js)
        x92a = scrapertools.find_single_match(data_js, 'var x92a = "([^"]*)";')
        x92b = scrapertools.find_single_match(data_js, 'var x92b = "([^"]*)";')
        if (x92a or 'var x92a = "";' in data_js) and (x92b or 'var x92b = "";' in data_js) : break

    # Resoldre url cridant a x92()
    if (x92a or 'var x92a = "";' in data_js) and (x92b or 'var x92b = "";' in data_js):
        return resoldre_x92(x92a, base64.b64decode(x92b))

    return ''
