# -*- coding: utf-8 -*-

import re, sys, base64, urllib
from platformcode import logger

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Clase auxiliar para desofuscar ciertas estructuras js

'''
Características que debe tener el código ofuscado:

1- Una primera variable que contiene un array muy largo de valores.
2- A continuación, una Self-Invoking Anonymous Function (hace una rotación de valores de la variable inicial, a parte de despistar con cookies)
3- Una función que resuelve a partir de la variable inicial.

La desofuscación consiste en:

- Substituir todas las llamadas a la función "resolver" por los valores que devuelve.
Ejs: _0x48bd('0x0','e(@1') => 'Schedule',  b('0x0', 'hHMQ') => 'JeIie'
Ejs: _0x48bd('0x0') => 'Schedule',  b('0x0') => 'JeIie'
Y cuando está dentro de un eval('...'):
Ejs: _0x48bd(\'0x0\',\'e(@1\') => \'Schedule\',  b(\'0x0\', \'hHMQ\') => \'JeIie\'
Ejs: _0x48bd(\'0x0\') => \'Schedule\',  b(\'0x0\') => \'JeIie\'

'''

class EstructuraInicial(object):

    def __init__(self, data):
        self.data = data

        self.funcion = ''  # nombre de la función js que resuelve la estructura
        self.lista = []    # lista de valores del array inicial del js

        self.detectado, self.msg = self._detectar_estructura()

        if self.detectado:
            # ~ logger.info(self.funcion)
            # ~ logger.info(self.data)
            # ~ logger.info(self.lista)
            # ~ logger.info(self.novedad)
            # crides a resolver amb dos paràmetres
            matches = re.compile("(%s\('([^']*)',\s*'([^']*)'\))" % self.funcion).findall(self.data)
            for i, match in enumerate(matches):
                x = self.unhex(match[2]) if match[2][:2] == '\\x' else match[2]
                valor = self._resolver_funcion(int(match[1], 16), x)
                
                if "'" not in valor:
                    self.data = self.data.replace(match[0], "'"+valor+"'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '"'+valor+'"')
                else:
                    # ~ print 'problema cometes no previst! ' + valor
                    return

            # crides a resolver amb dos paràmetres dins algun eval('')
            matches = re.compile("(%s\(\\\\'(.*?)\\\\',\s*\\\\'(.*?)\\\\'\))" % self.funcion).findall(self.data)
            for i, match in enumerate(matches):
                x = self.unhex(match[2]) if match[2][:2] == '\\x' else match[2]
                valor = self._resolver_funcion(int(match[1], 16), x)
                
                if "'" not in valor:
                    self.data = self.data.replace(match[0], "\\'"+valor+"\\'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '\\"'+valor+'\\"')
                else:
                    # ~ print 'problema cometes no previst! ' + valor
                    return

            # crides a resolver amb un paràmetre
            matches = re.compile("(%s\('([^']*)'\))" % self.funcion).findall(self.data)
            for i, match in enumerate(matches):
                valor = self._resolver_funcion(int(match[1], 16), '')
                
                if "'" not in valor:
                    self.data = self.data.replace(match[0], "'"+valor+"'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '"'+valor+'"')
                else:
                    # ~ print 'problema cometes no previst! ' + valor
                    return

            # crides a resolver amb un paràmetre dins algun eval('')
            matches = re.compile("(%s\(\\\\'(.*?)\\\\'\))" % self.funcion).findall(self.data)
            for i, match in enumerate(matches):
                valor = self._resolver_funcion(int(match[1], 16), '')
                
                if "'" not in valor:
                    self.data = self.data.replace(match[0], "\\'"+valor+"\\'")
                elif '"' not in valor:
                    self.data = self.data.replace(match[0], '\\"'+valor+'\\"')
                else:
                    # ~ print 'problema cometes no previst! ' + valor
                    return


    # Detectar si hay lo que se espera
    # --------------------------------
    def _detectar_estructura(self):

        # 1- Variable con lista de valores (guardar valores en self.lista y eliminar la variable del js)
        # --------------------------------
        m = re.search('var (\w*)\s*=\s*\[(.*?)\];', self.data)
        if not m: return False, '' #'No se encuentra el array inicial de valores!'
        
        nombre = m.group(1)
        self.lista  = m.group(2).split(',')
        for i, v in enumerate(self.lista): self.lista[i] = v.strip()[1:-1] # eliminar entre-comillado

        if self.lista[0][:2] == '\\x': # si los textos estan en hexa convertir a texto
            for i, v in enumerate(self.lista): self.lista[i] = self.unhex(v)

        self.data = self.data.replace(m.group(0), '') # eliminar bloque entero
        # ~ print nombre, m.group(1), m.group(2), m.group(3)
        # ~ logger.info('Nombre: %s' % nombre)


        # 2- Self-Invoking Anonymous Function (buscar número para rotar self.lista y eliminar función del js)
        # -----------------------------------
        m = re.search('\(function\(.*?}\(%s,\s*([^\)]*)\)\);' % nombre, self.data, flags=re.DOTALL)
        if not m: return False, '' #'No se encuentra la función anónima autoinvocada!'
        
        numero = int(m.group(1), 0)
        # ~ logger.info('Numero: %d' % numero)

        self.data = self.data.replace(m.group(0), '') # eliminar bloque entero

        for x in range(numero): self.lista.append(self.lista.pop(0))


        # 3- Función resolver que recibe dos parámetros (guardar nombre de la función y eliminar función del js)
        # ---------------------------------------------
        m = re.search('var (\w*)\s*=\s*function\s*\(\s*[^,]*,\s*[^\)]*\)\s*\{.*?\}\s*else\{\s*\w*\s*=\s*\w*;\s*\}\s*return \w*;\s*\};', self.data)
        if not m: return False, '' #'No se encuentra la función que resuelve!'

        self.funcion = m.group(1).strip()

        self.novedad = ''
        if '=(0x3+_0x' in m.group(0): self.novedad = '1'
        if "=(0x3+Math['pow'](0x7c,0x0)+_0x" in m.group(0): self.novedad = '2'
        
        self.data = self.data.replace(m.group(0), '') # eliminar bloque entero

        return True, '' #'*) Detectada estructura para desofuscar.\nVariable con %d elementos (rotación inicial de %d)\nFunción resolver: %s' % (len(self.lista), numero, self.funcion)


    # Resolver función principal
    # --------------------------
    def _resolver_funcion(self, num, s=''):
        r = str(self.lista[num])
        # ~ logger.debug('%s %s %s' % (num, s, r))
        r = base64.b64decode(r)
        
        x = ''
        for y in range(len(r)):
            x += '%' + ( '00' + hex(ord(r[y]))[2:] )[-2:]

        r = unicode(urllib.unquote(x), 'utf8')
        if s == '': return r
            
        t = range(256)
        if self.novedad == '1': # novetat 20190515
            for y in range(256): t[y] = (3 + y) % 256
        elif self.novedad == '2': # novetat 20190612
            for y in range(256): t[y] = (4 + y) % 256

        u = 0; w = ''
        for y in range(256):
            u = (u + t[y] + ord(s[(y % len(s))]) ) % 256;
            v = t[y]
            t[y] = t[u]
            t[u] = v

        A = 0; u = 0
        for y in range(len(r)):
            A = (A + 1) % 256
            u = (u + t[A]) % 256
            v = t[A]
            t[A] = t[u]
            t[u] = v
            w += unichr( ord(r[y]) ^ t[(t[A] + t[u]) % 256] )

        return w.encode('utf8')


    # Convertir de hexa a texto (Ej: '\x65\x66\x67' => 'efg')
    # -------------------------
    def unhex(self, txt):
        return re.sub("\\\\x[a-f0-9][a-f0-9]", lambda m: m.group()[2:].decode('hex'), txt)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Resolver para hdfull
# --------------------

# Convertir de hexa a texto (Ej: '\x65\x66\x67' => 'efg')
# -------------------------
def custom_unhex(txt):
    return re.sub("\\\\x[a-fA-F0-9][a-fA-F0-9]", lambda m: m.group()[2:].decode('hex'), txt)

def hdfull_providers(data):
    # ~ logger.debug(data)
    data = custom_unhex(data)
    # ~ logger.debug(data)

    m = re.search('var\s*(\w*)\s*=\s*\[(.*?)\];', data)
    if not m: return '' #'No se encuentra el array inicial de valores!'
    nombre = m.group(1)
    lista  = m.group(2).split(',')
    for i, v in enumerate(lista): lista[i] = v.strip()[1:-1] # eliminar entre-comillado
    # ~ logger.debug(nombre)
    # ~ logger.debug(lista)
    # ~ logger.debug(len(lista))
    
    # substituir valors de l'array inicial
    data = re.sub("%s\[(\d+)\]" % nombre, lambda m: '"'+lista[int(m.group(1))]+'"', data)
    # ~ logger.debug(data)

    # extreure t i l
    pt = re.compile('p\[(\d+)\]\s*=\s*\{"t":"([^"]*)').findall(data)
    if not pt: pt = re.compile('p\[(\d+)\]\s*=\s*\{\'t\':"([^"]*)').findall(data)
    dpt = dict(pt)
    # ~ logger.debug(dpt)
    if len(dpt) == 0: return hdfull_providers_01(data) # si falla provar mètode anterior

    pl = re.compile('p\[(\d+)\]\s*=\s*\{.*?"l":.*?return ([^}]*)', flags=re.DOTALL).findall(data)
    if not pl: pl = re.compile('p\[(\d+)\]\s*=\s*\{.*?\'l\':.*?return ([^}]*)', flags=re.DOTALL).findall(data)
    dpl = dict(pl)
    # ~ logger.debug(dpl)
    if len(dpl) == 0: return hdfull_providers_01(data) # si falla provar mètode anterior !?

    p = {}
    for num in dpl:
        t = dpt[num] if num in dpt else ''
        l = re.sub("(_0x[a-zA-Z0-9]+)", '_code_', dpl[num])
        p[num] = [t, l]

    return p


def hdfull_providers_01(data):

    # Obtener linea que hace el decode y desofuscar
    # ---------------------------------------------
    matches = re.compile("(var \w+\s*=\s*\[.*?\];\(function\(.*?)\n").findall(data)
    if not matches:
        # ~ logger.info('ERR1')
        # ~ logger.debug(data)
        return ''

    net = EstructuraInicial(matches[0])
    if not net.detectado:
        # ~ logger.info('ERR2')
        # ~ logger.debug(matches[0])
        # ~ logger.debug(data)
        return ''
    # ~ logger.debug(net.data) # Descomentar para analizar cuando hay cambios

    # Analizar código js desofuscado
    # ------------------------------

    # Cambiar p[0x0a] por p[10] ...
    net.data = re.sub("p\[0x([a-f0-9]+)\]", lambda m: 'p['+str(int(m.group(1), 16))+']', net.data)

    pt = re.compile("p\[(\d+)\]\['t'\]\s*=\s*'([^']*)'").findall(net.data)
    dpt = dict(pt)

    pl = re.compile("p\[(\d+)\]\['l'\]\s*=.*?return ([^;]*);", flags=re.DOTALL).findall(net.data)
    dpl = dict(pl)

    p = {}
    for num in dpl:
        t = dpt[num] if num in dpt else ''
        l = re.sub("(_0x[a-f0-9]+)", '_code_', dpl[num])
        p[num] = [t, l]

    return p

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Resolver para uptostream/uptobox
# --------------------------------

def uptostream_sumes(data):
    # ~ 'mPBM'+'A' => 'mPBMA'
    # [^.]+ per evitar "aa"+"bb".concat("cc")
    matches = re.findall("('([^']*)'\s*\+\s*'([^']*)')[^.]+", data, re.DOTALL)
    while matches:
        for tot, val1, val2 in matches:
            data = data.replace(tot, "'%s%s'" % (val1, val2))
        matches = re.findall("('([^']*)'\s*\+\s*'([^']*)')[^.]+", data, re.DOTALL)
    return data

def uptostream_valors_directes(func, codi, data):
    # ~ 'bYGYc':'REAYB',
    m1 = re.findall("('[^']+'):('[^']+')", codi, re.DOTALL)
    for nom, valor in m1:
        # ~ logger.info('%s %s' % (nom, valor))
        # ~ _0x1aca6d['bYGYc'] => 'REAYB'
        data = data.replace("%s[%s]" % (func, nom), valor)
    return data

def uptostream_funcio_simple(func, codi, data):
    # ~ 'seLyF':function(_0x5c1cc2){return _0x5c1cc2();},
    m1 = re.findall("('[^']+'):function\((\w+)\)\{return (\w+)\(\);\},", codi, re.DOTALL)
    for nom, p1, p2 in m1:
        # ~ logger.info('%s %s' % (nom, p1))
        if p1 == p2:
            # ~ _0x261dad['seLyF'](_0x1ec2fd) => _0x1ec2fd()
            data = re.sub("%s\[%s\]\(([^\)]+)\)" % (func, nom), '\\1()', data)
    return data

def uptostream_funcio_doble(func, codi, data):
    # ~ 'pdNqF':function(_0x54c0ef,_0x11ddb6){return _0x54c0ef===_0x11ddb6;},
    # ~ 'aZuro':function(_0x4771a9,_0x362d75){return _0x4771a9+_0x362d75;},
    m1 = re.findall("('[^']+'):function\((\w+),(\w+)\)\{return (\w+)(\+|===|!==)(\w+);\},", codi, re.DOTALL)
    for nom, p1, p2, p3, op, p4 in m1:
        if p1 == p3 and p2 == p4:
            # ~ _0x261dad['pdNqF']('REAYB','REAYB') => 'REAYB'==='REAYB'
            # ~ _0x261dad['aZuro'](_0x1ec2fd()+'/',_0x2f451f()) => _0x1ec2fd()+'/'+_0x2f451f()
            data = re.sub("%s\[%s\]\(([^,]+),([^\)]+)\)" % (func, nom), lambda m: m.group(1)+op+m.group(2), data)
    return data

def uptostream_ifs_fake(data):
    # ~ if('ZvMGL'!=='EeXpc'){return'0';}else{return 'unknown 0';} => return'0';
    m1 = re.findall("(if\('([^']+)'(===|!==)'([^']+)'\)\{return\s*('[^']+');\}else\{return\s*('[^']+');\})", data, re.DOTALL)
    for tot, p1, op, p2, v1, v2 in m1:
        if op == '===': cumple = (p1 == p2)
        else: cumple = (p1 != p2)
        data = data.replace(tot, 'return ' + (v1 if cumple else v2) + ';')
    return data


def uptostream_funcions(data):
    # ~ var _0x5524aa=()=>{return '360';};
    m1 = re.findall("var (\w+)=\(\)=>\{return\s*('[^']+');\};", data, re.DOTALL)
    for nom, valor in m1:
        # ~ _0x5524aa() => '360'
        data = data.replace(nom+'()', valor)

    # ~ var _0x275daa=function(){return '360';};
    m1 = re.findall("var (\w+)=function\(\)\{return\s*('[^']+');\};", data, re.DOTALL)
    for nom, valor in m1:
        # ~ _0x275daa() => '360'
        data = data.replace(nom+'()', valor)

    # ~ function _0x1efe38(){return '0';}
    m1 = re.findall("function (\w+)\(\)\{return\s*('[^']+');\}", data, re.DOTALL)
    for nom, valor in m1:
        # ~ _0x1efe38() => '0'
        data = data.replace(nom+'()', valor)

    return data

def uptostream_pilla_valor(data, valor):
    aux = re.findall("\['%s'\]=(\w+);" % valor, data, re.DOTALL)
    if not aux: return ''
    aux = re.findall("var %s='([^']+)';" % aux[0], data, re.DOTALL)
    if not aux: return ''
    return aux[0]


def decode_video_uptostream(data):
    matches = re.compile("(var \w+\s*=\s*\[.*?\];\(function\(.*?)\n").findall(data)
    if not matches: matches = re.compile("(var \w+\s*=\s*\[.*?\];\(function\(.*)$").findall(data)
    if not matches:
        logger.info('Not detected 1')
        # ~ logger.debug(data)
        return '', ''

    # ~ logger.debug(matches[0])
    net = EstructuraInicial(matches[0])
    if not net.detectado:
        logger.info('Not detected 2')
        return '', ''
    # ~ logger.debug(net.data)
    data = net.data
    # ~ logger.debug(data)

    data = uptostream_sumes(data)
    # ~ logger.debug(data)
    for i in range(10):
        ant = data
        # ~ logger.info('Range: '+str(i))
        matches = re.findall('(var (\w+)=\{(.*?)\};)', data, re.DOTALL)
        for tot, func, codi in matches:
            # ~ logger.info(func)
            data = uptostream_valors_directes(func, codi, data)
            data = uptostream_funcio_simple(func, codi, data)
            data = uptostream_funcio_doble(func, codi, data)
            if func+'[' not in data:
                data = data.replace(tot, '')
                
        data = uptostream_ifs_fake(data)
        # ~ logger.debug(data)
        if ant == data: break

    for i in range(10):
        ant = data
        # ~ logger.info('Range bis: '+str(i))
        data = uptostream_funcions(data)
        data = uptostream_sumes(data)
        # ~ logger.debug(data)
        if ant == data: break

    # ~ logger.debug(data)
    url = uptostream_pilla_valor(data, 'src').replace('\\/', '/')
    lbl = uptostream_pilla_valor(data, 'label')
    lang = uptostream_pilla_valor(data, 'lang')
    if lang and 'unknown' not in lang: lbl += ' (lang: ' + lang + ')'
    if not lbl: lbl = 'mp4'

    return lbl, url

# Ejemplos tratados:

# ~ var sources=[];;sources['push'](function setTheLink(){var _0x482edc=function(){return 'https:\/\/www49.uptostream.com';};var _0x2e4628=function(){return '1w7ai1ge217';};var _0xba92d5=function(){return '360';};function 'unknown 0'{return 'unknown 0';}function '0'{return'0';}var _0x2c9a2b=function(){return 'video.mp4';};let _0x20d5e2={};var _0x47bd64=_0x482edc()+'\/'+_0x2e4628()+'\/'+_0xba92d5()+'\/0\/'+_0x2c9a2b();var _0x3aa9dd='video/mp4';var _0x3c55a0='360p';var _0x5e8bb7='360';var _0x3c4af2='unknown 0';var _0x5581a1='0';_0x20d5e2['src']=_0x47bd64;_0x20d5e2['type']=_0x3aa9dd;_0x20d5e2['label']=_0x3c55a0;_0x20d5e2['res']=_0x5e8bb7;_0x20d5e2['lang']='unknown 0';_0x20d5e2['idLang']=_0x5581a1;return _0x20d5e2;}());

# ~ var sources=[];;sources['push'](function setTheLink(){var _0x13c5e5={'pNEYF':function(_0x1a6375,_0x2c29ee){return _0x1a6375===_0x2c29ee;},'ojfNB':'bQyou','ubLdu':'https://www49.uptostream.com','nGjbA':function(_0x3da3e9,_0x16274a){return _0x3da3e9!==_0x16274a;},'nGuvZ':'MZqSv','YVmhI':'video.mp4','IhiAB':'lmjXC','Epfcy':'unknown\\x200','khrWI':function(_0x43b7b2,_0x34553f){return _0x43b7b2===_0x34553f;},'Hnbta':'eucUC','PzenE':function(_0x457b4f,_0x5b72c9){return _0x457b4f+_0x5b72c9;},'hRosh':function(_0x316da3,_0x3beac8){return _0x316da3+_0x3beac8;},'AdgBe':function(_0xe17a4b,_0x30a02b){return _0xe17a4b+_0x30a02b;},'rLGhy':function(_0x2cf56c,_0x27956c){return _0x2cf56c+_0x27956c;},'oFcTW':function(_0x5ec7b1){return _0x5ec7b1();},'WMtII':function(_0x24a233){return _0x24a233();},'UevIi':function(_0x21ca86){return _0x21ca86();},'Ftugt':function(_0x50fc7d){return _0x50fc7d();}};var _0x5919e5=function(){return 'https://www49.uptostream.com';};var _0x23a5c8=function(){return '1w79ymv3f14';};var _0x1a5093=function(){return '360';};function 'unknown\\x200'{return 'unknown\\x200';}function '0'{return '0';}var _0x3d753a=function(){return 'video.mp4';};let _0x29f290={};var _0x5d7720=_0x5919e5()+'\/'+_0x23a5c8()+'\/'+_0x1a5093()+'\/0\/'+_0x13c5e5['Ftugt'](_0x3d753a);var _0xfb53c1='video/mp4';var _0x2eb538='360p';var _0x4dc0c6='360';var _0x26e5a6='unknown\\x200';var _0x4cd50d='0';_0x29f290['src']=_0x5d7720;_0x29f290['type']=_0xfb53c1;_0x29f290['label']=_0x2eb538;_0x29f290['res']=_0x4dc0c6;_0x29f290['lang']='unknown\\x200';_0x29f290['idLang']=_0x4cd50d;return _0x29f290;}());

# ~ var sources=[];;sources['push'](function setTheLink(){var _0x275daa=function(){return 'https://www49.uptostream.com';};var _0x59e2e9=function(){return '1w794vy433c';};var _0x5eaf55=function(){return '360';};function 'unknown 0'{return 'unknown 0';}function '0'{return '0';}var _0x4701bf=function(){return 'video.mp4';};let _0x20e47f={};var _0x36555c=_0x275daa()+'\/'+_0x59e2e9()+'\/'+_0x5eaf55()+'\/0\/'+_0x4701bf();var _0x104bb3='video/mp4';var _0x4ab534='360p';var _0x186fe0='360';var _0x34006f='unknown 0';var _0x195204='0';_0x20e47f['src']=_0x36555c;_0x20e47f['type']=_0x104bb3;_0x20e47f['label']=_0x4ab534;_0x20e47f['res']=_0x186fe0;_0x20e47f['lang']='unknown 0';_0x20e47f['idLang']=_0x195204;return _0x20e47f;}());

# ~ var sources=[];;sources['push'](function setTheLink(){var _0x1ed4f7=function(){return 'https://www49.uptostream.com';};var _0x4894b3=function(){return '1w78f6yaaae';};var _0x536ea1=function(){return '360';};function _0x54d5f3(){return 'unknown\\x200';}function _0x58a55d(){return'0';}var _0x2e54c1=function(){return 'video.mp4';};let _0x1ab408={};var _0x216610=_0x1ed4f7()+'\/'+_0x4894b3()+'\/'+_0x536ea1()+'\/'+_0x58a55d()+'\/'+_0x2e54c1();var _0x1de350='video/mp4';var _0x255e0e='360p';var _0x38870d='360';var _0x336fe5='unknown 0';var _0x57ffef='0';_0x1ab408['src']=_0x216610;_0x1ab408['type']=_0x1de350;_0x1ab408['label']=_0x255e0e;_0x1ab408['res']=_0x38870d;_0x1ab408['lang']='unknown 0';_0x1ab408['idLang']=_0x57ffef;return _0x1ab408;}());


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Resolver para cookie sucuri
# ---------------------------

def rshift(val, n): return val>>n if val >= 0 else (val+0x100000000)>>n

def get_sucuri_cookie(data):

    matches = re.findall("S='([^']+)", data, flags=re.DOTALL)
    if not matches: return '', ''
    S = matches[0]
    A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    r = ''
    l = 0
    U = 0
    for i in range(len(S)):
        c = A.find(S[i])
        U = (U << 6) + c
        l += 6
        while l >= 8:
            l -= 8
            a = rshift(U, l) & 0xff
            r += chr(a)

    # ~ logger.debug(r)
    nomvar = r[0]

    r = r.replace('location.reload();', '')
    r = r.replace("';path=/;max-age=86400'", "''")
    r = r.replace('\n', ' ')
    r = r.replace('+ %s' % nomvar, ' ')
    r = re.sub('\.charAt\(([0-9]+)\)', lambda m: '['+m.group(1)+']', r)
    r = re.sub('String\.fromCharCode\(([0-9x]+)\)', lambda m: 'chr('+m.group(1)+')', r)
    r = re.sub('\.slice\(([0-9]+),\s*([0-9]+)\)', lambda m: '['+m.group(1)+':'+m.group(2)+']', r)
    r = re.sub('\.substr\(([0-9]+),\s*([0-9]+)\)', lambda m: '['+m.group(1)+':'+str( int(m.group(1)) + int(m.group(2)) )+']', r)
    r = r.replace('?', 'x')
    r = r.replace('@', 'y')

    res = r.split(';document.cookie=')
    try:
        e = eval (res[0].replace('%s=' % nomvar, ''))
        ck = eval (res[1].split("+ '';")[0])
    except:
        logger.debug(res)
        e = ''
        ck = ''
    return ck.replace('=', ''), e

